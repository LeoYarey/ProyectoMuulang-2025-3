# ProyectoMuuLang
ProyectoSistemasBaseUno
Este proyecto sera un analizador lexico en Phyton, que incluye ciclos for y while asi como una pequeña interfaz
Materia: Programacion de sistemas base uno
Universidad Autonoma De Tamaulipas
Grado: 8vo Grupo: G
Profesor: Muñoz Quintero Dante Adolfo
Integrantes:
•	CERVANTES DE LA ROSA ANGEL ALEJANDRO
•	PANIAGUA RICO JUAN JULIAN
•	YAÑEZ REYNA LEONARDO
•	MENDEZ DE JESUS EMMANUEL
•	SAENZ RICO FERNANDO AARON
